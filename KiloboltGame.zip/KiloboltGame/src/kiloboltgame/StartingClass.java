package kiloboltgame;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.net.URL;

/* 
 * (1)'implement Runnable' is required for Threads require a run method that determines what 
 * will happen in that thread 
 * */
public class StartingClass extends Applet implements
		Runnable, KeyListener {
	private String sgameTitle = "Q-Bot Alpha";
	// hero character
	private Hero hero;
	private Image image, character,background;
	private Graphics second;
	// character variable
	private URL base;
	private String characterImage = "data/character.png";
	private String backgroundImage = "data/background.png";
	// background variables
	private static Background bkground1, bkground2;

	/*
	 * (0 @Override ) The @Override tests for errors upon compilation. In this
	 * case, we are using it to annotate that we are overriding methods from a
	 * parent class. It informs you when you make mistakes.
	 */
	@Override
	/*
	 * (3 init() ) When the applet runs for the first time, it will run the
	 * init() method (much like how a typical program runs the main(String
	 * args[]) method)
	 * 
	 * the init method will define parameters for the applet 1. Size of the
	 * applet 2. Background color 3. Applet Title
	 */
	public void init() {
		// size for resolution
		setSize(1280, 720);
		// background color using the Color superclass with ".Black" is the
		// constant importing the color
		setBackground(Color.BLACK);
		// this will make sure your game/application will take immediate focus
		// on start to begin the game loop
		setFocusable(true);
		// this will allow the game/application to pick up key presses and
		// releases for the current Applet
		addKeyListener(this);
		/*
		 * import 'Frame' to create a Frame object called frame. This is
		 * slightly complicated, but just know that the first line assigns the
		 * applet window to the frame variable an the second line just sets the
		 * title to be Q-Bot Alpha
		 */
		Frame frame = (Frame) this.getParent().getParent();
		frame.setTitle(sgameTitle);
		// Character
		// this will assign a value to 'character'
		try {
			base = getDocumentBase();
		} catch (Exception e) {

		}
		// character & image location
		character = getImage(base, characterImage);
		background = getImage(base, backgroundImage);
		// end of character & image Character
	}

	@Override
	public void start() {
		// a constructor will handle this given the constructors parameters
		bkground1 = new Background(0, 0);
		bkground2 = new Background(2160, 0);
		// initialize the object hero created from the Robot.class
		hero = new Hero();
		// (1 Thread )'thread' will allow the game/app to run simultaneous
		// process/methods
		Thread thread = new Thread(this);
		thread.start();

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub

	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void run() {
		// game loop
		while (true) {
			hero.update();
			bkground1.updatebkground();
			bkground2.updatebkground();
			/*
			 * (2 repaint() ) built in method - calls the paint method (in which
			 * we draw objects onto the screen), but every 17 milliseconds, the
			 * paint method will be called.
			 */
			repaint();
			try {
				Thread.sleep(17);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

	}

	// Character
	public void update(Graphics g) {
		if (image == null) {
			image = createImage(this.getWidth(),
					this.getHeight());
			second = image.getGraphics();
		}
		second.setColor(getBackground());
		second.fillRect(0, 0, getWidth(), getHeight());
		second.setColor(getForeground());
		paint(second);
		g.drawImage(image, 0, 0, this);
		}

	// this section will be used to draw the graphics & character or update the
	// character on the screen
	public void paint(Graphics g) {
		// draws background
		g.drawImage(background, bkground1.getBkgroundX(), bkground1.getBkgroundY(), this);
		g.drawImage(background, bkground2.getBkgroundX(), bkground2.getBkgroundY(), this);
		// draw the 'hero'
		g.drawImage(character, Hero.getCenterX() - 98, Hero.getCenterY() - 96, this);
	}

	// Character

	@Override
	public void keyPressed(KeyEvent e) {
		// ***************************************************************************************
		// NOTE: this will be for physical keys currently till port to Android
		// ***************************************************************************************
		/*
		 * (3 'e' )'e' is the object or variable you created to associate with
		 * the method keyPressed and KeyEvent class
		 */

		// switch statements compares a 'key' in this instance then checks the
		// matching variable to
		// perform the proper statements or actions and return what was pressed
		// (i.e. Up, Down, etc.)
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			hero.jump();
			break;
		case KeyEvent.VK_DOWN:
			System.out.println("Down was pressed");
			break;
		case KeyEvent.VK_LEFT:
			hero.moveLeft();
			break;
		case KeyEvent.VK_RIGHT:
			hero.moveRight();
			break;
		}
		// end of switch statement

	}

	@Override
	public void keyReleased(KeyEvent e) {
		// switch statements compares a 'key' in this instance then checks the
		// matching variable to
		// perform the proper statements or actions and return what was pressed
		// (i.e. Up, Down, etc.)
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			System.out.println("Up was released");
			break;
		case KeyEvent.VK_DOWN:
			System.out.println("Down was released");
			break;
		case KeyEvent.VK_LEFT:
			hero.stop();
			break;
		case KeyEvent.VK_RIGHT:
			hero.stop();
			break;
		}
		// end of switch statement

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}
	public static Background getBkground1() {
		return bkground1;
	}

	public static Background getBkground2() {
		return bkground2;
	}

}
